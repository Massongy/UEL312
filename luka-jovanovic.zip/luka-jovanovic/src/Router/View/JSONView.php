<?php declare(strict_types=1);

namespace Framework312\Router\View;

use Framework312\Router\Request;
use Symfony\Component\HttpFoundation\Response;

abstract class JSONView extends BaseView
{
    protected function get(Request $request): mixed {
        return ["message" => "JSONView GET"];
    }

    protected function post(Request $request): mixed {
        return ["message" => "JSONView POST"];
    }

    static public function use_template(): bool {
        return false;
    }

    public function render(Request $request): Response {
        $data = $request->getMethod() === 'POST' ? $this->post($request) : $this->get($request);
        return new Response(json_encode($data, JSON_PRETTY_PRINT), 200, ['Content-Type' => 'application/json']);
    }
}