<?php declare(strict_types=1);

namespace Framework312\Router\View;

use Framework312\Router\Request;
use Symfony\Component\HttpFoundation\Response;

abstract class HTMLView extends BaseView
{
    protected function get(Request $request): mixed {
        return "<h1>HTMLView GET</h1>";
    }

    protected function post(Request $request): mixed {
        return "<h1>HTMLView POST</h1>";
    }

    static public function use_template(): bool {
        return false;
    }

    public function render(Request $request): Response {
        $data = $request->getMethod() === 'POST' ? $this->post($request) : $this->get($request);
        return new Response($data, 200, ['Content-Type' => 'text/html']);
    }
}