<?php
echo "Le serveur fonctionne";
?>